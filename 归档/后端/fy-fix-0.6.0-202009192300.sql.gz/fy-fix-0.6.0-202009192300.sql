-- MySQL dump 10.13  Distrib 5.6.48, for Linux (x86_64)
--
-- Host: localhost    Database: fyclub
-- ------------------------------------------------------
-- Server version	5.6.48-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fy_admin`
--

DROP TABLE IF EXISTS `fy_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_admin` (
  `id` int(11) NOT NULL COMMENT '管理员编号',
  `user` text NOT NULL COMMENT '管理员账号',
  `pass` text NOT NULL COMMENT '管理员密码（MD5）',
  `name` text NOT NULL COMMENT '管理员姓名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬后台管理账户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_admin`
--

LOCK TABLES `fy_admin` WRITE;
/*!40000 ALTER TABLE `fy_admin` DISABLE KEYS */;
INSERT INTO `fy_admin` VALUES (2020000000,'root','0000000000000000000000000000000','0000系统默认管理'),(2020000001,'pika','eb87e7115a52f83d4a7b08653e373d5f','2020研发部皮卡丘'),(2020000002,'冷浩杰','5b70803a12dea85db39989b2b10b318b','2021维修部冷浩杰'),(2020000003,'wisdompanda','afdec7005cc9f14302cd0474fd0f3c96','2021研发部唐琦');
/*!40000 ALTER TABLE `fy_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_confs`
--

DROP TABLE IF EXISTS `fy_confs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_confs` (
  `id` int(11) NOT NULL COMMENT '编号',
  `name` text NOT NULL COMMENT '数据名称',
  `info` text NOT NULL COMMENT '注释',
  `data` text NOT NULL COMMENT '数据',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬报修核心配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_confs`
--

LOCK TABLES `fy_confs` WRITE;
/*!40000 ALTER TABLE `fy_confs` DISABLE KEYS */;
INSERT INTO `fy_confs` VALUES (0,'Global_Flag','全局报修开关','1'),(1,'Global_Year','全局年份时间','2020'),(2,'Global_Tips','全局公告内容','1.送修前请移除电源外其余外设配件\r\n\r\n（包括鼠标 接收器 U盘 内存卡等）\r\n\r\n2.如要更换配件，请提前购买准备好\r\n\r\n3.如需重装系统，送修前电脑充满电\r\n\r\n4.请备份好数据，不对丢失数据负责\r\n\r\n5.我们不是万能，不保证一定能修好\r\n'),(3,'Global_Days','每天提交限额','10'),(4,'Global_Week','每周提交限额','50'),(5,'Global_Mont','每月提交限额','150'),(6,'Global_Time','全局超时时间','15');
/*!40000 ALTER TABLE `fy_confs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_datas`
--

DROP TABLE IF EXISTS `fy_datas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_datas` (
  `id` int(11) NOT NULL COMMENT '编号',
  `name` text NOT NULL,
  `data` int(11) NOT NULL COMMENT '数据',
  `info` text NOT NULL COMMENT '注释',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬维修统计数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_datas`
--

LOCK TABLES `fy_datas` WRITE;
/*!40000 ALTER TABLE `fy_datas` DISABLE KEYS */;
INSERT INTO `fy_datas` VALUES (0,'flag',1,'0-正常  1-已满'),(1,'total_num',1,'总共报修-所有'),(2,'month_num',0,'本月报修-所有'),(3,'order_am1',0,'本周报修-会员'),(4,'order_am2',0,'本周报修-游客'),(5,'order_vip',0,'今日报修-会员'),(6,'order_nop',0,'今日报修-游客'),(7,'id_user',1,'总共数据-用户'),(8,'id_staf',1,'总共数据-职员'),(9,'id_orde',1,'总共数据-订单'),(10,'id_info',0,'总共数据-问题'),(11,'wa1',0,'周一-会员'),(12,'wa2',0,'周二-会员'),(13,'wa3',0,'周三-会员'),(14,'wa4',0,'周四-会员'),(15,'wa5',0,'周五-会员'),(16,'wa6',0,'周六-会员'),(17,'wa7',0,'周天-会员'),(18,'id_vips',1,'总共数据-会员'),(19,'id_feed',1,'总共数据-反馈'),(20,'id_admi',3,'总共数据-管理'),(21,'wb1',0,'周一-游客'),(22,'wb2',0,'周二-游客'),(23,'wb3',0,'周三-游客'),(24,'wb4',0,'周四-游客'),(25,'wb5',0,'周五-游客'),(26,'wb6',0,'周六-游客'),(27,'wb7',0,'周天-游客'),(28,'',0,'保留'),(29,'',0,'保留');
/*!40000 ALTER TABLE `fy_datas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_feeds`
--

DROP TABLE IF EXISTS `fy_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_feeds` (
  `fkid` int(11) NOT NULL AUTO_INCREMENT,
  `urid` int(11) NOT NULL COMMENT '反馈用户',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '反馈时间',
  `pnum` text NOT NULL COMMENT '手机号码',
  `name` text NOT NULL COMMENT '反馈用户',
  `text` text NOT NULL COMMENT '消息文本',
  PRIMARY KEY (`fkid`)
) ENGINE=InnoDB AUTO_INCREMENT=2020000014 DEFAULT CHARSET=utf8 COMMENT='飞扬技术问题反馈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_feeds`
--

LOCK TABLES `fy_feeds` WRITE;
/*!40000 ALTER TABLE `fy_feeds` DISABLE KEYS */;
INSERT INTO `fy_feeds` VALUES (2020000000,2020000000,'2020-01-01 00:00:00','10000000000','系统','默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容默认反馈内容');
/*!40000 ALTER TABLE `fy_feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_infos`
--

DROP TABLE IF EXISTS `fy_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_infos` (
  `ssid` int(8) NOT NULL COMMENT '搜索编号',
  `urid` int(8) NOT NULL COMMENT '作者编号',
  `twid` int(8) NOT NULL COMMENT '提问编号',
  `good` int(8) NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `ansd` int(1) NOT NULL DEFAULT '0' COMMENT '是否回答',
  `cont` text COMMENT '关联问题',
  `tips` text COMMENT '关键内容',
  `wzbt` text NOT NULL,
  `text` text COMMENT '消息文本',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '编写时间',
  PRIMARY KEY (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬技术问题查找';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_infos`
--

LOCK TABLES `fy_infos` WRITE;
/*!40000 ALTER TABLE `fy_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `fy_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_order`
--

DROP TABLE IF EXISTS `fy_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_order` (
  `tbid` int(8) NOT NULL COMMENT '订单编号',
  `urid` int(8) NOT NULL COMMENT '用户编号',
  `wxid` int(8) NOT NULL DEFAULT '20200000' COMMENT '技工编号',
  `flag` int(1) NOT NULL DEFAULT '0' COMMENT '状态-0未接-1已接-2完成-3放弃-4技术关闭-5-系统关闭',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `wcsj` datetime NOT NULL COMMENT '关闭时间',
  `jdsj` datetime NOT NULL COMMENT '接单时间',
  `gmsj` text NOT NULL COMMENT '购买时间',
  `pnum` text NOT NULL COMMENT '手机号码',
  `sbzl` text NOT NULL COMMENT '设备种类',
  `dnpp` text NOT NULL COMMENT '电脑品牌',
  `dnxh` text NOT NULL COMMENT '电脑型号',
  `wxsm` text NOT NULL COMMENT '维修说明',
  `wxtp` text NOT NULL COMMENT '维修图片',
  `bxzt` text NOT NULL COMMENT '保修状态',
  `gzlx` text NOT NULL COMMENT '故障类型',
  `qqid` text NOT NULL COMMENT 'QQ号码',
  UNIQUE KEY `tbid` (`tbid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬维修订单查找';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_order`
--

LOCK TABLES `fy_order` WRITE;
/*!40000 ALTER TABLE `fy_order` DISABLE KEYS */;
INSERT INTO `fy_order` VALUES (2020000000,2020000000,2020000000,5,'2000-01-01 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00','10000000000','其他设备（Other）','其他','其他','无','0000000000000000','0','0','0');
/*!40000 ALTER TABLE `fy_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_stack`
--

DROP TABLE IF EXISTS `fy_stack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_stack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_stack`
--

LOCK TABLES `fy_stack` WRITE;
/*!40000 ALTER TABLE `fy_stack` DISABLE KEYS */;
/*!40000 ALTER TABLE `fy_stack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_staff`
--

DROP TABLE IF EXISTS `fy_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_staff` (
  `urid` int(11) NOT NULL,
  `wxid` int(11) NOT NULL COMMENT '技术编号',
  `last` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上次时间',
  `next` int(11) NOT NULL DEFAULT '1' COMMENT '下次天数',
  `wxcs` int(11) NOT NULL COMMENT '维修次数',
  `aval` tinyint(1) NOT NULL COMMENT '允许接单：技术员设置0-停止 1-可用',
  `flag` int(1) NOT NULL COMMENT '可用标识,系统设置，0-停止 1-可用',
  `qqky` int(1) NOT NULL COMMENT '使用QQ',
  `qqid` text NOT NULL COMMENT 'QQ号码',
  `sets` int(1) NOT NULL COMMENT '自定参数',
  `tips` text NOT NULL COMMENT '备注内容',
  PRIMARY KEY (`wxid`),
  UNIQUE KEY `wxid_2` (`wxid`),
  KEY `wxid` (`wxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_staff`
--

LOCK TABLES `fy_staff` WRITE;
/*!40000 ALTER TABLE `fy_staff` DISABLE KEYS */;
INSERT INTO `fy_staff` VALUES (2020000000,2020000000,'2020-01-01 00:00:00',999,0,0,0,0,'000000000',0,'系统默认维修'),(2020000001,2020000001,'2020-01-01 00:00:00',1,0,0,0,1,'894662978',0,'研发部皮卡丘');
/*!40000 ALTER TABLE `fy_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy_users`
--

DROP TABLE IF EXISTS `fy_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy_users` (
  `id` int(11) NOT NULL COMMENT '用户编号',
  `pnum` bigint(11) DEFAULT NULL COMMENT '手机号码',
  `vips` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否会员',
  `fixs` tinyint(1) NOT NULL DEFAULT '0' COMMENT '技术人员',
  `seid` bigint(20) NOT NULL DEFAULT '0' COMMENT '会话编号',
  `bans` tinyint(1) NOT NULL DEFAULT '0' COMMENT '禁止报修',
  `name` text COMMENT '会员姓名',
  `code` text COMMENT '短信验证码',
  `mail` text COMMENT '邮件地址',
  `flag` int(1) NOT NULL DEFAULT '0' COMMENT '当前维修',
  `hyid` int(11) NOT NULL DEFAULT '0' COMMENT '会员编号',
  `wxid` int(11) NOT NULL DEFAULT '0' COMMENT '技术编号',
  `init` int(11) NOT NULL DEFAULT '0' COMMENT '是否初始化',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `txtp` text NOT NULL COMMENT '头像图片',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='飞扬维修用户登录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy_users`
--

LOCK TABLES `fy_users` WRITE;
/*!40000 ALTER TABLE `fy_users` DISABLE KEYS */;
INSERT INTO `fy_users` VALUES (2020000000,10000000000,1,1,0,1,'未分配','不可用','root@fyscu.com',0,2020000000,2020000000,1,'2019-12-31 16:00:00','0.png'),(2020000001,15998977068,1,0,66613632232977,0,'皮卡丘','已登录','pikachuim@qq.com',1,2020000001,2020000001,1,'2019-12-31 16:00:00','0.png');
/*!40000 ALTER TABLE `fy_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-20  0:21:53
