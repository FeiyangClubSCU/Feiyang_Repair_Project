// pages/home/home.js
import {fail} from "../../dist/toast/toast";

const app = getApp()
Page({
    /*---------------------------------------页面初始数据---------------------------------------*/
    data: {
        tip: '',
        isShow: false,
        isuser: 1,
        status: 0,
        hidden: false,
        confirmflag: true,
        button_isuse: false,
        infPnum: '',
        infQQid: '',
        infName: '',
        infBxzt: '',
        infDnpp: '',
        infDnxh: '',
        infFlag: '',
        infGmsj: '',
        infGzlx: '',
        infJdsj: '',
        infSblx: '',
        infTime: '',
        infWxsm: '',
        infWxtp: '',
        infWcsj: '',
        infTbid: '',
        picker: ['一天', '三天', '五天'],
        steps: [{text: '', desc: '订单创建'},
            {text: '', desc: '成功接单'},
            {text: '', desc: '订单完成'}]
    },
    imgArray: ['https://ossweb-img.qq.com/images/lol/web201310/skin/big84000.jpg',
        'https://ossweb-img.qq.com/images/lol/web201310/skin/big84001.jpg',
        'https://ossweb-img.qq.com/images/lol/web201310/skin/big39000.jpg',
        'https://ossweb-img.qq.com/images/lol/web201310/skin/big39000.jpg'],
    swiperList: [{
        id: 0, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big84000.jpg'
    }, {
        id: 1, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big84001.jpg'
    }, {
        id: 2, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big39000.jpg'
    }, {
        id: 3, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big10001.jpg'
    }, {
        id: 4, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big25011.jpg'
    }, {
        id: 5, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big21016.jpg'
    }, {
        id: 6, type: 'image', url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big99008.jpg'
    }],

    /*---------------------------------------获取用户状态---------------------------------------*/
    indexGetUserStatus: function () {
        var temp_this = this
        var temp_seid = wx.getStorageSync('seid');
        var temp_pnum = wx.getStorageSync('pnum');
        console.log(temp_seid)
        console.log(temp_pnum)
        wx.request({
            url: 'https://fix.fyscu.com/api/onpage/index/get_status.php',
            data: {"seid": temp_seid, "pnum": temp_pnum,},
            method: 'GET',
            header: {'content-type': 'application/json'},
            success: function (res) {
                console.log(res.data)
                if (res.data === "") {
                    wx.reLaunch({url: '/pages/datas/datas',})
                } else {
                    var temp1 = String(res.data)
                    temp_this.setData({isuser: temp1.substr(0, 1), status: temp1.substr(1, 1)})
                }
            },
            fail: function (res) {
                console.log("[获取用户状态]没有返回当前状态")
                wx.showModal({
                    title: '获取用户状态失败',
                    content: res.data,
                })
                wx.reLaunch({url: '/pages/datas/datas',})
            }
        })
    },
        /*---------------------------------------获取用户信息---------------------------------------*/
    indexGetUserFxData: function () {
        var temp_this = this
        var temp_seid = wx.getStorageSync('seid')
        var temp_pnum = wx.getStorageSync('pnum')
        wx.request({
                url: 'https://fix.fyscu.com/api/onpage/index/get_fxdata.php',
                data: {"seid": temp_seid, "pnum": temp_pnum,},
                method: 'GET',
                header: {'content-type': 'application/json'},
                success: function (res) {
                    console.log(res.data)
                    if(temp_this.data.status=='1' 
                     ||temp_this.data.status=='2'){
                      temp_this.setData({
                        infPnum: res.data.pnum,
                        infBxzt: res.data.bxzt,
                        infName: res.data.name,
                        infDnpp: res.data.dnpp,
                        infDnxh: res.data.dnxh,
                        infFlag: res.data.flag,
                        infGmsj: res.data.gmsj,
                        infGzlx: res.data.gzlx,
                        infJdsj: res.data.jdsj,
                        infQQid: res.data.qqid,
                        infSblx: res.data.sbzl,
                        infTime: res.data.time,
                        infWxsm: res.data.wxsm,
                        infWxtp: res.data.wxtp,
                        infWcsj: res.data.wcsj,
                        infTbid: res.data.tbid,
                    })
                  }      
                },
                fail:function(res) {
                    console.log("[获取用户状态]没有返回当前状态")
                    wx.showModal(
                    {
                        title: '获取用户状态失败',
                        content: res.data,
                    })
                },
            }
        )
    },
        /*---------------------------------------关闭用户订单---------------------------------------*/
    indexPutUserChange: function () {
        var temp_this = this
        var temp_seid = wx.getStorageSync('seid')
        var temp_pnum = wx.getStorageSync('pnum')
        wx.request({
                url: 'https://fix.fyscu.com/api/onpage/index/get_finish.php',
                data: {"seid": temp_seid,
                       "pnum": temp_pnum,
                       "flag": 2,},
                method: 'GET',
                header: {'content-type': 'application/json'},
                success: function (res) {
                    console.log(res.data)
                    wx.reLaunch({url: '/pages/datas/datas',})
                    }
                },
            )
        wx.showToast({
            title: '成功',
            icon: 'success',
            duration: 2000
        })
        this.onPullDownRefresh()

        },
    indexPutUserGiveup: function () {
        var temp_this = this
        var temp_seid = wx.getStorageSync('seid')
        var temp_pnum = wx.getStorageSync('pnum')
        wx.request({
                url: 'https://fix.fyscu.com/api/onpage/index/get_finish.php',
                data: {"seid": temp_seid,
                       "pnum": temp_pnum,
                       "flag": 3,},
                method: 'GET',
                header: {'content-type': 'application/json'},
                success: function (res) {
                    console.log(res.data)
                }
            },
        )
        wx.showToast({
            title: '成功',
            icon: 'success',
            duration: 2000
        })
        this.onPullDownRefresh()
    },
/*--------------------------------------跳转维修页面---------------------------------------*/
indexGetUserRepair:function () {
    wx.showLoading({title: '加载中...'})
    var userLogin=app.getUserInfo()
    if(userLogin==false) {
      wx.navigateTo({
        url: '/pages/login/login', success: function (res) {
            wx.hideLoading({
                complete: (res) => {
                },
            })
        }
    })
    }
    wx.navigateTo({
        url: '/pages/posts/posts', success: function (res) {
            wx.hideLoading({
                complete: (res) => {
                },
            })
        }
    })
}
,
/*--------------------------------------监听页面加载---------------------------------------*/
onLoad: function (options) {
    var userLogin=app.getUserInfo()
    
    if(userLogin==false) {
      this.setData({
        isuser:1,
        status:0
      })
    }
    else{
      this.indexGetUserStatus()
      this.indexGetUserFxData()
    }
    
}
,
/*--------------------------------------用户下拉动作---------------------------------------*/
onPullDownRefresh: function () {
    wx.showNavigationBarLoading()
    console.log("beforeload111")
    this.onLoad()
    console.log("afterload111")
    setTimeout(function () {
        wx.hideNavigationBarLoading()
        wx.stopPullDownRefresh()
    }, 1500);
}
,
/*--------------------------------------页面上拉触底---------------------------------------*/
onReachBottom: function () {
    if (this.data.status == 0 && this.data.isuser == 0) {
        wx.showLoading({title: '加载数据中...',})
        setTimeout(function () {
            wx.hideLoading({
                complete: (res) => {
                },
            })
        }, 1500)
    }
},

  look:function(){
    wx.showLoading({
      title: '加载中...'
    })
    wx.navigateTo({
      url: '/pages/detail/detail?infTbid='+this.data.infTbid,
      success: function (res) {
        wx.hideLoading({
          complete: (res) => {},
        })
      }
    })
  },
/*---------------------------------------------------------------------------------------*/
})




/*---------------------------------------xxxxxxxx---------------------------------------*/
/*
detail:function() {
  wx.showLoading({
    title: '加载中...'
  })
  wx.navigateTo({
    url: '/pages/fixdetail/fixdetail',
    success:function(res) {
      wx.hideLoading({
        complete: (res) => {},
      })
    }
  })
},

previewImg:function (event) {
  console.log(event.currentTarget.dataset.src)
  var src = event.currentTarget.dataset.src;//获取data-src
  var imgList = event.currentTarget.dataset.list;//获取data-list

  wx.previewImage({
    current: src, // 当前显示图片的http链接
    urls: imgList // 需要预览的图片http链接列表
  })
},




copy:function(e) {
  console.log(e)
  wx.setClipboardData({
    data: e.currentTarget.dataset.text,
    success:function(res) {
      wx.getClipboardData({
        complete: (res) => {
        },
      })
    }
  })
},

confirm_finish:function() {
  this.setData({
    isShow: true,
    confirmflag:true,
    tip:'确定维修完成了嘛？'
  })
},

first:function () {
  wx.showToast({
    title:'维修已完成',
    icon:'success',
    duration:1500
  })
  this.setData({
    isShow:false
  })
},

hidebtn: function(){
  this.setData({
    isShow: false,
  })
},

cancel:function() {
  this.setData({
    isShow: true,
    confirmflag:false,
    tip:'确定要撤消维修嘛？'
  })
},

second:function() {
  wx.showToast({
    title:'订单已撤销',
    icon:'success',
    duration:1500
  })
  this.setData({
    isShow:false
  })
},



*/