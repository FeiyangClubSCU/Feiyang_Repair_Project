<?php
$posts = $_GET;
$get_status_seid = $posts['seid'];  //获取会话号码
$get_status_pnum = $posts['pnum'];  //获取手机号码
$get_status_path = dirname(dirname(__FILE__));
include $get_status_path.'/../module/database.php';
$get_status_tmp0=0;
$get_status_tmp1=0;
$get_status_user=db_alls('fy_users'); //获取用户表
$get_status_orde=db_alls('fy_order'); //获取订单表
echo "pikapikapikapika";
while($get_status_row1=$get_status_user->fetch_assoc()){
    if( $get_status_row1['pnum'] == $get_status_pnum       //查询用户登录信息
     && $get_status_row1['seid'] == $get_status_seid){
         $get_status_tmp0=1;
        if($get_status_row1['fixs']==0) $get_status_cxid=$get_status_row2['urid'];
        else                            $get_status_cxid=$get_status_row2['wxid'];
        while($get_status_row2=$get_status_orde->fetch_assoc()){
            echo $get_status_cxid.$get_status_row1['id'].$get_status_row2['flag'].$get_status_row2['flag'];
            if( $get_status_cxid == $get_status_row1['id'] and (($get_status_row2['flag'] == '0')or ($get_status_row2['flag'] == '1')) ){
                    if($get_status_row1['fixs']==0) {
                        while($get_status_row3=$get_status_user->fetch_assoc()){
                            if( $get_status_row3['id'] == $get_status_row2['wxid']){
                                $get_status_name=$get_status_row3['name'];
                                $get_status_pnum=$get_status_row3['pnum'];
                                break;
                            }
                        }
                    }
                    if($get_status_row1['fixs']==1) {
                        while($get_status_row3=$get_status_user->fetch_assoc()){
                            if( $get_status_row3['id'] == $get_status_row2['id']){
                                $get_status_name=$get_status_row3['name'];
                                $get_status_pnum=$get_status_row3['pnum'];
                                break;
                             }
                        }
                    }
                    $get_status_tmp1=1;
                    $get_status_json = json_encode(array("qqid"=>$get_status_row2['qqid'],
                                                         "pnum"=>$get_status_row2['pnum'],
                                                         "name"=>$get_status_name,
                                                         "pnum"=>$get_status_pnum,
                                                         "time"=>$get_status_row2['time'],
                                                         "jdsj"=>$get_status_row2['jdsj'],
                                                         "gmsj"=>$get_status_row2['gmsj'],
                                                         "flag"=>$get_status_row2['flag'],
                                                         "sbzl"=>$get_status_row2['sbzl'],
                                                         "dnpp"=>$get_status_row2['dnpp'],
                                                         "dnxh"=>$get_status_row2['dnxh'],
                                                         "wxsm"=>$get_status_row2['wmsm'],
                                                         "wxtp"=>$get_status_row2['wmtp'],
                                                         "bxzt"=>$get_status_row2['bxzt'],
                                                         "gzlx"=>$get_status_row2['gzlx'],
                                        ),JSON_UNESCAPED_UNICODE);
                    echo $get_status_json;
                    break;

            }
        }
    }
    if($get_status_tmp0==1){
        $get_status_tmp1=1;
        echo "0";break;
    }
}
if($get_status_tmp0!=1) echo "0";
?>