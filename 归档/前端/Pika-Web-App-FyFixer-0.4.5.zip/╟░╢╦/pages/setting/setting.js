// pages/option/option.js
import Toast from '../../dist/toast/toast';
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    img:'https://ossweb-img.qq.com/images/lol/web201310/skin/big10001.jpg',
    picker: ['男','女'],
    QQ:'',
    sex:'',
    phone:'',

    name:'',
    email:'',
  },

  getname:function(e) {
    this.setData({
      name:e.detail.value
    })
  },

  getsex:function(e) {
    let index = e.detail.value
    console.log(e.detail.value)
    if(index == 0) {
      this.setData({
        sex:'男'
     })
    } else{
    this.setData({
      sex:'女'
   })
  }
  },

  getphone:function(e) {
    this.setData({
      phone:e.detail.value
    })
  },

  getQQ:function(e) {
    this.setData({
      QQ:e.detail.value
    })
  },

  getemail:function(e) {
    this.setData({
      email:e.detail.value
    })
  },

  submit:function(e) {
    if (this.data.name == '') {
      Toast.fail('姓名为空')
      return false;
    }
    /*
    if (this.data.sex == '') {
      Toast.fail('性别为空')
      return false;
    }
    if (this.data.phone == '') {
      Toast.fail('手机号为空')
      return false;
    }
    if (this.data.QQ == '') {
      Toast.fail('QQ号为空')
      return false;
    }
    */
    if (this.data.email == '') {
      Toast.fail('邮箱为空')
      return false;
    }
    else{
      var temp_this = this
      var temp_seid = wx.getStorageSync('seid');
      var temp_pnum = wx.getStorageSync('pnum');
      console.log(temp_seid)
      console.log(temp_pnum)
      wx.request({
          url: 'https://fix.fyscu.com/api/onpage/about/put_userid.php',
          data: {"seid": temp_seid, "pnum": temp_pnum,
                 "name": temp_this.data.name,
                 "mail": temp_this.data.email,
        },
          method: 'GET',
          header: {'content-type': 'application/json'},
          success: function (res) {
            console.log(res.data)
          },
      })
      wx.showToast({
        title:'提交成功',
        icon:'success',
        duration:1500
      }),
      wx.reLaunch({
        url: '/pages/about/about?namedata=' + this.data.name +'&phonedata=' + this.data.phone + '&sexdata=' + this.data.sex,
      })
    }
  },
  onLoad: function (options) {
    var temp_this = this
    var temp_seid = wx.getStorageSync('seid');
    var temp_pnum = wx.getStorageSync('pnum');
    console.log(temp_seid)
    console.log(temp_pnum)
    wx.request({
        url: 'https://fix.fyscu.com/api/onpage/about/get_userid.php',
        data: {"seid": temp_seid, "pnum": temp_pnum,},
        method: 'GET',
        header: {'content-type': 'application/json'},
        success: function (res) {
          console.log(res.data)
          temp_this.setData({
            email:res.data.mail,
            name:res.data.name,
          })
        },
    })
  },

  PickerChange(e) {
    console.log(e);
    var indexname = e.currentTarget.id;
    if(indexname === 'interval')
    this.setData({
      intervalindex: e.detail.value
    })
    if(indexname === 'connecttype')
    this.setData({
      connecttypeindex: e.detail.value
    })
  },
  upload(){
    wx.chooseImage({
      count: 1, //默认9
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album'], //从相册选择
      success: (res) => {
        if (this.data.img.length != 0) {
          this.setData({
            imgList: this.data.img.concat(res.tempFilePaths)
          })
        } else {
          this.setData({
            img: res.tempFilePaths
          })
        }
      }
    });

  }
})
